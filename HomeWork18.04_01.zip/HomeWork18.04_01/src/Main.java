public class Main {
    public static void main(String[] args) {
        char[][] alphabetArray = new char[5][5];
        char letter = 'А';
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                alphabetArray[i][j] = letter;
                letter++;
            }
        }
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(alphabetArray[i][j] + " ");
            }
            System.out.println();
        }
    }
}