public class Main {
    public static String compressString(String str) {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        char current = str.charAt(0);
        for (int i = 1; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == current) {
                count++;
            } else {
                sb.append(current);
                if (count > 1) {
                    sb.append(count);
                }
                count = 1;
                current = ch;
            }
        }
        sb.append(current);
        if (count > 1) {
            sb.append(count);
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        String str = "AAABBBCCCDDEG";
        System.out.println(compressString(str));
    }
}