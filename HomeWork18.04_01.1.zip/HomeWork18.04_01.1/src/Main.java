public class Main {
    public static void main(String[] args) {
        int n = 4;
        int[][] arr = new int[n][n];
        int left = 0, right = n - 1, top = 0, bottom = n - 1;
        int num = 1;
        while (left <= right && top <= bottom) {
            for (int col = left; col <= right; col++) {
                arr[top][col] = num++;
            }
            top++;
            for (int row = top; row <= bottom; row++) {
                arr[row][right] = num++;
            }
            right--;
            for (int col = right; col >= left; col--) {
                arr[bottom][col] = num++;
            }
            bottom--;
            for (int row = bottom; row >= top; row--) {
                arr[row][left] = num++;
            }
            left++;
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(String.format("%02d ", arr[i][j]));
            }
            System.out.println();
        }
    }
}